/* SBTXT theme script. Source layout: see README (kept compact for Shopify's per-page JS budget). */
(function () {
'use strict';
var cfg = window.SBTXT || {};
var money = function (cents) {
var fmt = cfg.moneyFormat || '${{amount}}';
var value = (cents / 100).toFixed(2);
var whole = value.split('.')[0];
var frac = value.split('.')[1];
var withComma = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '.' + frac;
return fmt
.replace(/\{\{\s*amount\s*\}\}/, withComma)
.replace(/\{\{\s*amount_no_decimals\s*\}\}/, whole)
.replace(/\{\{\s*amount_with_comma_separator\s*\}\}/, whole.replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ',' + frac)
.replace(/\{\{\s*amount_no_decimals_with_comma_separator\s*\}\}/, whole.replace(/\B(?=(\d{3})+(?!\d))/g, '.'));
};
function openDrawer(el) {
if (!el) return;
el.setAttribute('open', '');
document.documentElement.style.overflow = 'hidden';
var focusable = el.querySelector('button, a, input');
if (focusable) focusable.focus();
}
function closeDrawer(el) {
if (!el) return;
el.removeAttribute('open');
document.documentElement.style.overflow = '';
}
document.addEventListener('click', function (e) {
var openBtn = e.target.closest('[data-open]');
if (openBtn) {
e.preventDefault();
openDrawer(document.getElementById(openBtn.getAttribute('data-open')));
return;
}
var closeBtn = e.target.closest('[data-close]');
if (closeBtn) {
e.preventDefault();
closeDrawer(closeBtn.closest('[data-drawer]'));
}
});
document.addEventListener('keydown', function (e) {
if (e.key !== 'Escape') return;
var open = document.querySelector('[data-drawer][open]');
if (open) closeDrawer(open);
});
var drawer = document.getElementById('cart-drawer');
function renderDrawer(html) {
if (!drawer || !html) return;
var parsed = new DOMParser().parseFromString(html, 'text/html');
var fresh = parsed.querySelector('#cart-drawer .cart-drawer__panel');
var current = drawer.querySelector('.cart-drawer__panel');
if (fresh && current) current.innerHTML = fresh.innerHTML;
}
function updateCount(count) {
document.querySelectorAll('[data-cart-count]').forEach(function (el) {
el.textContent = count;
if (count > 0) el.removeAttribute('hidden'); else el.setAttribute('hidden', '');
});
}
function refreshDrawer(openIt) {
return fetch((cfg.rootUrl || '/') + '?sections=cart-drawer', { headers: { 'Accept': 'application/json' } })
.then(function (r) { return r.json(); })
.then(function (json) {
renderDrawer(json['cart-drawer']);
var countEl = drawer && drawer.querySelector('[data-drawer-count]');
if (countEl) updateCount(parseInt(countEl.getAttribute('data-drawer-count'), 10) || 0);
if (openIt) openDrawer(drawer);
});
}
document.addEventListener('submit', function (e) {
var form = e.target;
if (!form.matches('[data-ajax-cart]')) return;
if (!window.fetch || !drawer) return;
e.preventDefault();
var btn = form.querySelector('[type="submit"]');
var label = btn ? btn.querySelector('[data-label]') : null;
var original = label ? label.textContent : '';
if (btn) { btn.setAttribute('aria-disabled', 'true'); if (label) label.textContent = cfg.addingText || 'adding'; }
var body = new FormData(form);
body.append('sections', 'cart-drawer');
fetch((cfg.rootUrl || '/') + 'cart/add.js', { method: 'POST', body: body, headers: { 'Accept': 'application/json' } })
.then(function (r) { return r.json(); })
.then(function (json) {
if (json.status && json.status >= 400) { throw new Error(json.description || json.message || 'error'); }
if (json.sections && json.sections['cart-drawer']) {
renderDrawer(json.sections['cart-drawer']);
var countEl = drawer.querySelector('[data-drawer-count]');
if (countEl) updateCount(parseInt(countEl.getAttribute('data-drawer-count'), 10) || 0);
openDrawer(drawer);
} else {
return refreshDrawer(true);
}
})
.catch(function (err) {
var note = form.querySelector('[data-form-error]');
if (note) { note.textContent = String(err.message || err).toLowerCase(); note.hidden = false; }
})
.then(function () {
if (btn) { btn.removeAttribute('aria-disabled'); if (label) label.textContent = original; }
});
});
function changeLine(key, quantity, root) {
if (root) root.setAttribute('aria-busy', 'true');
return fetch((cfg.rootUrl || '/') + 'cart/change.js', {
method: 'POST',
headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
body: JSON.stringify({ id: key, quantity: quantity, sections: 'cart-drawer' })
})
.then(function (r) { return r.json(); })
.then(function (json) {
if (json.sections && json.sections['cart-drawer']) {
renderDrawer(json.sections['cart-drawer']);
updateCount(json.item_count || 0);
}
if (root && root.matches('[data-cart-page]')) window.location.reload();
})
.catch(function () { window.location.reload(); });
}
document.addEventListener('click', function (e) {
var remove = e.target.closest('[data-remove]');
if (remove) {
e.preventDefault();
changeLine(remove.getAttribute('data-remove'), 0, remove.closest('[data-cart-root]'));
return;
}
var step = e.target.closest('[data-step]');
if (step) {
e.preventDefault();
var input = step.parentNode.querySelector('input');
if (!input) return;
var next = Math.max(parseInt(input.min || '0', 10), (parseInt(input.value, 10) || 0) + parseInt(step.getAttribute('data-step'), 10));
input.value = next;
if (input.hasAttribute('data-line')) changeLine(input.getAttribute('data-line'), next, input.closest('[data-cart-root]'));
}
});
document.addEventListener('change', function (e) {
var input = e.target;
if (input.matches('input[data-line]')) {
changeLine(input.getAttribute('data-line'), Math.max(0, parseInt(input.value, 10) || 0), input.closest('[data-cart-root]'));
}
});
document.querySelectorAll('[data-product]').forEach(function (root) {
var dataEl = root.querySelector('[data-variants]');
if (!dataEl) return;
var variants;
try { variants = JSON.parse(dataEl.textContent); } catch (err) { return; }
var idInput = root.querySelector('input[name="id"]');
var priceEl = root.querySelector('[data-price]');
var compareEl = root.querySelector('[data-compare]');
var btn = root.querySelector('[data-add]');
var btnLabel = btn ? btn.querySelector('[data-label]') : null;
var addText = btn ? btn.getAttribute('data-add-text') : '';
var soldText = btn ? btn.getAttribute('data-sold-text') : '';
var unavailText = btn ? btn.getAttribute('data-unavailable-text') : '';
var mainImg = root.querySelector('[data-gallery-main] img');
var gallery = root.querySelector('[data-gallery-main]');
var optionInputs = root.querySelectorAll('[data-option] input[type="radio"]');
function selected() {
var opts = [];
root.querySelectorAll('[data-option]').forEach(function (group) {
var checked = group.querySelector('input:checked');
opts.push(checked ? checked.value : null);
});
return opts;
}
function find(opts) {
for (var i = 0; i < variants.length; i++) {
var v = variants[i];
var ok = true;
for (var j = 0; j < opts.length; j++) { if (opts[j] !== null && v.options[j] !== opts[j]) { ok = false; break; } }
if (ok) return v;
}
return null;
}
function markAvailability(opts) {
root.querySelectorAll('[data-option]').forEach(function (group, gi) {
group.querySelectorAll('label').forEach(function (label) {
var input = label.querySelector('input');
if (!input) return;
var probe = opts.slice();
probe[gi] = input.value;
var v = find(probe);
label.classList.toggle('is-unavailable', !(v && v.available));
});
});
root.querySelectorAll('[data-option-value]').forEach(function (el) {
var gi = parseInt(el.getAttribute('data-option-value'), 10);
if (opts[gi]) el.textContent = opts[gi].toLowerCase();
});
}
function apply() {
var opts = selected();
var v = find(opts);
markAvailability(opts);
if (!v) {
if (btn) { btn.setAttribute('disabled', ''); if (btnLabel) btnLabel.textContent = unavailText; }
return;
}
if (idInput) idInput.value = v.id;
if (priceEl) priceEl.textContent = money(v.price);
if (compareEl) {
if (v.compare_at_price && v.compare_at_price > v.price) { compareEl.textContent = money(v.compare_at_price); compareEl.hidden = false; }
else compareEl.hidden = true;
}
if (btn) {
if (v.available) { btn.removeAttribute('disabled'); if (btnLabel) btnLabel.textContent = addText; }
else { btn.setAttribute('disabled', ''); if (btnLabel) btnLabel.textContent = soldText; }
}
if (v.featured_image && mainImg && root.getAttribute('data-swap-on-variant') === 'true') {
mainImg.src = v.featured_image.src;
mainImg.srcset = '';
}
var colour = opts.join(' ').toLowerCase();
if (gallery) gallery.setAttribute('data-world', /black/.test(colour) ? 'black' : 'bone');
var url = new URL(window.location.href);
url.searchParams.set('variant', v.id);
window.history.replaceState({}, '', url.toString());
}
optionInputs.forEach(function (input) { input.addEventListener('change', apply); });
apply();
root.querySelectorAll('[data-thumb]').forEach(function (thumb) {
thumb.addEventListener('click', function () {
if (!mainImg) return;
mainImg.src = thumb.getAttribute('data-src');
mainImg.srcset = thumb.getAttribute('data-srcset') || '';
mainImg.alt = thumb.getAttribute('data-alt') || '';
root.querySelectorAll('[data-thumb]').forEach(function (t) { t.removeAttribute('aria-current'); });
thumb.setAttribute('aria-current', 'true');
});
});
});
if ('IntersectionObserver' in window) {
var io = new IntersectionObserver(function (entries) {
entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } });
}, { rootMargin: '0px 0px -8% 0px' });
document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });
} else {
document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('is-in'); });
}
})();
